﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Aplics.Nominix.DTOS.EmpleadosNomina
{
    public class ConceptoCatalogoResponseDTO
    {
        public string Code { get; set; }    
        public string Name { get; set;}
    }
}
