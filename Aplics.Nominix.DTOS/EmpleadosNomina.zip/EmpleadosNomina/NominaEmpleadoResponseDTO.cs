﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Aplics.Nominix.DTOS.EmpleadosNomina
{
    public class NominaEmpleadoResponseDTO
    {
        public string Codigo { get; set; }
        public string Nombre { get; set; }
        public string Estatus{ get; set; }
    }
}
