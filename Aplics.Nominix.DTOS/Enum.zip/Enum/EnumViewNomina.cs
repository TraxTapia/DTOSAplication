﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Aplics.Nominix.DTOS.Enum
{
    public enum EnumViewNomina
    {
        Nomina = 1,
        EmpleadoNomina=2
    }
}
